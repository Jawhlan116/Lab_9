$source="C:\ProgramData\MySQL\MySQL Server 8.0\Data\216-20.log"
$destination="C:\Users\User\Desktop\audit_logs"

while($true){
    Copy-Item $source -Destination $destination -Force
    Write-Host "Copied at $(Get-Date)" -ForegroundColor Green
    Start-Sleep -Seconds 3
}